package asteroids_sounds;

import java.io.BufferedInputStream;
import java.io.IOException;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;

/**
 * Contains the necessary methods to play sound clips for the game "Asteroids"
 * 
 * @author vaisuliafu
 *
 */
@SuppressWarnings("serial")
public class Sounds extends JFrame
{
    /** The audio clip representation of an Asteroids ship firing a cannon */
    private Clip shipBullet;

    /** The audio clip representation of an Asteroid's ship exhaust flame */
    private Clip shipFlame;

    /** The audio clip representation of a Large Asteroid exploding */
    private Clip bangLarge;

    /** The audio clip representation of a Medium Asteroid exploding */
    private Clip bangMedium;

    /** The audio clip representation of a Small Asteroid exploding */
    private Clip bangSmall;

    /** The audio clip representation of a UFO exploding */
    private Clip bangUFO;

    /** The audio clip representation of a user Ship exploding */
    private Clip bangShip;

    /** The audio clip representation of a large UFO */
    private Clip ufoBig;

    /** The audio clip representation of a small UFO */
    private Clip ufoSmall;

    /** The audio clip representation of the ship sensor beat 1 */
    private Clip beat1;

    /** The audio clip representation of the ship sensor beat 2 */
    private Clip beat2;

    /** Empty placeholder clip */
    private Clip emptyClip;

    /**
     * The constructor for a Sounds object.
     * 
     * This constructor pro-actively creates all of the games audio clips so that they may be retrieved continuously
     * throughout the game via the Sounds' classes other methods.
     */
    public Sounds ()
    {
        // Create the necessary Asteroids game audio clips
        this.shipBullet = createClip("/asteroids_sounds/fire.wav");
        this.shipFlame = createClip("/asteroids_sounds/thrust.wav");
        this.bangLarge = createClip("/asteroids_sounds/bangLarge.wav");
        this.bangMedium = createClip("/asteroids_sounds/bangMedium.wav");
        this.bangSmall = createClip("/asteroids_sounds/bangSmall.wav");
        this.bangUFO = createClip("/asteroids_sounds/bangAlienShip.wav");
        this.bangShip = createClip("/asteroids_sounds/bangShip.wav");
        this.ufoBig = createClip("/asteroids_sounds/saucerBig.wav");
        this.ufoSmall = createClip("/asteroids_sounds/saucerSmall.wav");
        this.beat1 = createClip("/asteroids_sounds/beat1.wav");
        this.beat2 = createClip("/asteroids_sounds/beat2.wav");
    }

    /**
     * Terminates all of audio clips in this Sounds object.
     */
    public void terminateAllClips ()
    {
        // Make an array of all clip String representations
        String[] clip_arr = { "shipBullet", "shipFlame", "bangLarge", "bangMedium", "bangSmall", "bangUFO", "bangShip",
                "ufoBig", "ufoSmall", "beat1", "beat2" };

        // Use enhanced loop to terminate each clip
        for (String clips : clip_arr)
        {
            this.terminateClip(clips);
        }
    }

    /**
     * Plays the specified audio clip if it exists. Else, does nothing.
     * 
     * @param str is the string representation of the desired audio clip.
     * @param can take values -1 for a continuously looping clip, 0 for a non-looping clip, and 1 for a fixed iteration
     *            loop.
     */
    public void playClip (String str, int type)
    {
        // Terminate clip if its already playing
        terminateClip(str);

        // Play it immediately
        selectClip(str).setFramePosition(0);

        // Determine play type
        if (type == 0)
        {
            selectClip(str).start();
        }
        else if (type == 1)
        {
            selectClip(str).loop(10);
        }
        else if (type == -1)
        {
            selectClip(str).loop(selectClip(str).LOOP_CONTINUOUSLY);
        }
    }

    /**
     * Terminates the specified audio clip if it is actively playing. Else, does nothing.
     * 
     * @param str is the string representation of the desired audio clip.
     */
    public void terminateClip (String str)
    {
        // Stop if already playing
        if (selectClip(str).isRunning())
        {
            selectClip(str).stop();
        }
    }

    /**
     * Creates an audio clip from a sound file.
     */
    private Clip createClip (String soundFile)
    {
        // Opening the sound file this way will work no matter how the
        // project is exported. The only restriction is that the
        // sound files must be stored in a package.
        try (BufferedInputStream sound = new BufferedInputStream(getClass().getResourceAsStream(soundFile)))
        {
            // Create and return a Clip that will play a sound file. There are
            // various reasons that the creation attempt could fail. If it
            // fails, return null.
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(sound));
            return clip;
        }
        catch (LineUnavailableException e)
        {
            System.out.println("Line Unavailable");
            return null;
        }
        catch (IOException e)
        {
            System.out.println("IO Exception");
            return null;
        }
        catch (UnsupportedAudioFileException e)
        {
            System.out.println("Unsupported Audio File");
            return null;
        }
    }

    /**
     * Returns the Clip object who's variable name matches the string parameter.
     * 
     * @param str
     * @return
     */
    private Clip selectClip (String str)
    {
        // Matching the argument to its respective Clip
        if (str.equals("shipBullet"))
        {
            return this.shipBullet;
        }
        else if (str.equals("shipFlame"))
        {
            return this.shipFlame;
        }
        else if (str.equals("bangLarge"))
        {
            return this.bangLarge;
        }
        else if (str.equals("bangMedium"))
        {
            return this.bangMedium;
        }
        else if (str.equals("bangSmall"))
        {
            return this.bangSmall;
        }
        else if (str.equals("bangUFO"))
        {
            return this.bangUFO;
        }
        else if (str.equals("bangShip"))
        {
            return this.bangShip;
        }
        else if (str.equals("ufoBig"))
        {
            return this.ufoBig;
        }
        else if (str.equals("ufoSmall"))
        {
            return this.ufoSmall;
        }
        else if (str.equals("beat1"))
        {
            return this.beat1;
        }
        else if (str.equals("beat2"))
        {
            return this.beat2;
        }
        else
        {
            return this.emptyClip;
        }
    }
}
