package asteroids.game;

import static asteroids.game.Constants.*;
import java.awt.*;
import java.awt.geom.Path2D;
import javax.swing.*;

/**
 * The area of the display in which the game takes place.
 */
@SuppressWarnings("serial")
public class Screen extends JPanel
{
    /** Legend that is displayed across the screen */
    private String legend;

    /** Game controller */
    private Controller controller;

    /**
     * Creates an empty screen
     */
    public Screen (Controller controller)
    {
        this.controller = controller;
        this.setLayout(new BorderLayout());
        legend = "";
        setPreferredSize(new Dimension(SIZE, SIZE));
        setMinimumSize(new Dimension(SIZE, SIZE));
        setBackground(Color.black);
        setForeground(Color.white);
        setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 120));
        setFocusable(true);
    }

    /**
     * Set the legend
     */
    public void setLegend (String legend)
    {
        this.legend = legend;
    }

    /**
     * Paint the participants onto this panel
     */
    @Override
    public void paintComponent (Graphics graphics)
    {
        // Use better resolution
        Graphics2D g = (Graphics2D) graphics;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        // Do the default painting
        super.paintComponent(g);

        // Draw each participant in its proper place
        for (Participant p : controller)
        {
            p.draw(g);
        }

        // Draw the legend across the middle of the panel
        int size = g.getFontMetrics().stringWidth(legend);
        g.drawString(legend, (SIZE - size) / 2, SIZE / 2);
        g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 40));

        // Draw the game statistic headers
        if (legend.equals("Asteroids") == false) // We don't want this on splash screen
        {
            // Draw the score at the top left
            g.drawString(this.controller.getScore(), 25, 50);

            // Draw the current level at the top right
            g.drawString(this.controller.getLevel(), (SIZE - 50), 50);

            // Draw the current number of lives remaining
            int x = 25;
            int y = 90;
            int z = Integer.parseInt(this.controller.getLives());

            // Paint the ship outline further and further over for each life
            for (int i = 0; i < z; ++i, x += 30)
            {
                g.draw(paintShipLifeOutline(x, y));
            }
        }
    }

    /**
     * Returns the outline of the ship facing north at the specified coordinates.
     * 
     * @param x is the desired x-coordinate.
     * @param y is the desired y-coordinate.
     * @return
     */
    private Shape paintShipLifeOutline (int x, int y)
    {
        // Draw the shape
        Path2D.Double poly = new Path2D.Double();
        poly.moveTo(x, y - 21);
        poly.lineTo(x - 12, y + 21);
        poly.lineTo(x - 10, y + 14);
        poly.lineTo(x + 10, y + 14);
        poly.lineTo(x + 12, y + 21);
        poly.closePath();

        return poly;
    }
}
