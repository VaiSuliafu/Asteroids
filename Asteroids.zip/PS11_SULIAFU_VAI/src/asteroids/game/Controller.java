package asteroids.game;

import static asteroids.game.Constants.*;
import java.awt.event.*;
import java.util.Iterator;
import javax.swing.*;
import asteroids.participants.Asteroid;
import asteroids.participants.Ship;
import asteroids.participants.UFO;
import asteroids_sounds.*;

/**
 * Controls a game of Asteroids.
 */
public class Controller implements KeyListener, ActionListener, Iterable<Participant>
{
    /** The state of all the Participants */
    private ParticipantState pstate;

    /** The ship (if one is active) or null (otherwise) */
    private Ship ship;

    /** The ufo (if one is active) or null (otherwise) */
    private UFO ufo;

    /** When this timer goes off, it is time to refresh the animation */
    private Timer refreshTimer;

    /** When this timer goes off, it is time to place a UFO */
    private Timer ufoTimer;

    /** When this timer goes off, it is time to play the beat */
    private Timer beatTimer;

    /** The beatTimer's delay */
    private int beatDelay;

    /** Represents which beat is currently being played */
    private int beat;

    /**
     * The time at which a transition to a new stage of the game should be made. A transition is scheduled a few seconds
     * in the future to give the user time to see what has happened before doing something like going to a new level or
     * resetting the current level.
     */
    private long transitionTime;

    /** The active level of the game being played */
    private int level;

    /** Number of lives left */
    private int lives;

    /** The score of the game currently being played */
    private int score;

    /** The game display */
    private Display display;

    /** The game sounds */
    private Sounds sounds;

    /**
     * Constructs a controller to coordinate the game and screen
     */
    public Controller ()
    {
        // Initialize the ParticipantState
        pstate = new ParticipantState();

        // Initialize the game's sounds object
        this.sounds = new Sounds();

        // Initialize the controllers beat
        this.beat = 1;

        // Initialize the game level
        setLevel(1);

        // Initialize the game score
        score = 0;

        // Initialize the number of lives
        lives = 3;

        // Set up the refresh timer.
        refreshTimer = new Timer(FRAME_INTERVAL, this);

        // Clear the transitionTime
        transitionTime = Long.MAX_VALUE;

        // Record the display object
        display = new Display(this);

        // Bring up the splash screen and start the refresh timer
        splashScreen();

        display.setVisible(true);
        refreshTimer.start();
    }

    /**
     * This makes it possible to use an enhanced for loop to iterate through the Participants being managed by a
     * Controller.
     */
    @Override
    public Iterator<Participant> iterator ()
    {
        return pstate.iterator();
    }

    /**
     * Returns the ship, or null if there isn't one
     */
    public Ship getShip ()
    {
        return ship;
    }

    /**
     * Configures the game screen to display the splash screen
     */
    private void splashScreen ()
    {
        // Clear the screen, reset the level, and display the legend
        clear();
        display.setLegend("Asteroids");

        // Place four asteroids near the corners of the screen.
        placeAsteroids(this.level);
    }

    /**
     * The game is over. Displays a message to that effect.
     */
    private void finalScreen ()
    {
        display.setLegend(GAME_OVER);
        display.removeKeyListener(this);
    }

    /**
     * Place a new ship in the center of the screen. Remove any existing ship first.
     */
    private void placeShip ()
    {
        // Place a new ship
        Participant.expire(ship);
        ship = new Ship(SIZE / 2, SIZE / 2, -Math.PI / 2, this);
        addParticipant(ship);
        display.setLegend("");
    }

    /**
     * Places a new UFO of the specified size outside of the screen.
     * 
     * @param 'size' can take values of 0 = small alien ship and 1 = large alien ship
     * @throws IllegalArgumentException
     */
    private void placeUFO (int size) throws IllegalArgumentException
    {
        // Check arguments
        if (size != 0 && size != 1)
        {
            throw new IllegalArgumentException();
        }

        // Expire the existing UFO if one exists
        Participant.expire(ufo);

        // Randomly generate the starting coordinates just outside the screen
        int[] arr = { -1, 1 };
        int x_start = arr[RANDOM.nextInt(2)] * RANDOM.nextInt(15) + 725;
        int y_start = arr[RANDOM.nextInt(2)] * RANDOM.nextInt(15) + 725;

        // Call the constructor and add the participant
        ufo = new UFO(size, x_start, y_start, 0, this);
        addParticipant(ufo);
        display.setLegend("");
    }

    /**
     * Randomly places 3+n asteroids on the screen.
     */
    private void placeAsteroids (int n)
    {
        // First make the default four asteroids
        for (int i = 0; i < 4; ++i)
        {
            addParticipant(new Asteroid(2, -1, -1, this));
        }

        // Now make the additional asteroids per active level past level 1
        while (n > 1)
        {
            addParticipant(new Asteroid(2, -1, -1, this));
            n--;
        }
    }

    /**
     * Clears the screen so that nothing is displayed
     */
    private void clear ()
    {
        pstate.clear();
        display.setLegend("");
        ship = null;
    }

    /**
     * Sets things up and begins a new game.
     */
    private void initialScreen ()
    {
        // Clear the screen
        clear();

        // Initialize and start the beatTimer
        beatDelay = INITIAL_BEAT;
        beatTimer = new Timer(beatDelay, this);
        beatTimer.start();

        // Place asteroids
        placeAsteroids(this.level);

        // Start generating UFO times as of level 2
        if (this.level >= 2)
        {
            // Set a UFO Timer for the next 5 seconds
            startUFOTimer();
        }

        // Place the ship
        placeShip();

        // Start listening to events (but don't listen twice)
        display.removeKeyListener(this);
        display.addKeyListener(this);

        // Give focus to the game screen
        display.requestFocusInWindow();
    }

    /**
     * Adds a new Participant
     */
    public void addParticipant (Participant p)
    {
        pstate.addParticipant(p);
    }

    /**
     * This method is called when the user ship is destroyed.
     * 
     * The method decrements the number of player lives, and schedules a transition.
     */
    public void shipDestroyed ()
    {
        // Null out the ship
        ship = null;

        // Decrement lives
        lives--;

        // Since the ship was destroyed, schedule a transition
        scheduleTransition(END_DELAY);
    }

    /**
     * This method is called when an asteroid is destroyed.
     * 
     * If the current count of asteroids is 0, a transition will be scheduled.
     */
    public void asteroidDestroyed ()
    {
        // If all the asteroids are gone, schedule a transition
        if (countAsteroids() == 0)
        {
            scheduleTransition(END_DELAY);
        }
    }

    /**
     * This method is called when a UFO is destroyed.
     * Upon a destruction, a transition will be scheduled.
     */
    public void UFODestroyed ()
    {
        // If the UFO is destroyed, schedule a transition
        if (countUFOs() == 0)
        {
            scheduleTransition(END_DELAY);
        }
    }

    /**
     * Sets the active level of the game to specified int x.
     */
    private void setLevel (int x)
    {
        this.level = x;
    }

    /**
     * Returns a string representing the current level of the game.
     */
    public String getLevel ()
    {
        Integer x = this.level;
        return x.toString();
    }

    /**
     * Returns a string representing the current number of remaining lives.
     */
    public String getLives ()
    {
        Integer x = this.lives;
        return x.toString();
    }

    /**
     * Returns a string representing the current score of the active game.
     * 
     * @return
     */
    public String getScore ()
    {
        Integer x = this.score;
        return x.toString();
    }

    /**
     * Returns this controllers Sounds object
     */
    public Sounds getSounds ()
    {
        return this.sounds;
    }

    /**
     * Increments the score by the amount of the argument 'score'.
     * 
     * @param score
     */
    public void setScore (int points)
    {
        this.score += points;
    }

    /**
     * Schedules a transition m msecs in the future
     */
    private void scheduleTransition (int m)
    {
        transitionTime = System.currentTimeMillis() + m;
    }

    /**
     * This method will be invoked because of button presses and timer events.
     */
    @Override
    public void actionPerformed (ActionEvent e)
    {
        // The start button has been pressed. Stop whatever we're doing
        // and bring up the initial screen
        if (e.getSource() instanceof JButton)
        {
            // Stop sounds
            this.sounds.terminateAllClips();

            // Reset game statistics
            this.lives = 3;
            this.level = 1;
            this.score = 0;
            transitionTime = Long.MAX_VALUE;

            // Reload game
            initialScreen();
        }

        // Time to refresh the screen and deal with keyboard input
        else if (e.getSource() == refreshTimer)
        {
            // It may be time to make a game transition
            performTransition();

            // Move the participants to their new locations
            pstate.moveParticipants();

            // Refresh screen
            display.refresh();
        }
        else if (e.getSource() == ufoTimer)
        {
            // Stop the timer
            ufoTimer.stop();

            if (this.level == 2 && this.countAsteroids() > 0)
            {
                // Level 2 spawns a large/slow UFO
                placeUFO(1);
            }
            else if (this.level > 2 && this.countAsteroids() > 0)
            {
                // Levels 3 and up spawn a small/fast UFO
                placeUFO(0);
            }
        }
        else if (e.getSource() == beatTimer)
        {
            // Alternate and play the beats
            playBeat();
        }
    }

    /**
     * Updates and plays the beat.
     */
    public void playBeat ()
    {
        // Alternate and play the beats
        if (this.beat == 1)
        {
            this.sounds.playClip("beat1", 0);
            this.beat = 2;
        }
        else if (this.beat == 2)
        {
            this.sounds.playClip("beat2", 0);
            this.beat = 1;
        }

        // Decrement the beat delay by 150ms to a floor of 250ms
        if (this.beatDelay > FASTEST_BEAT)
        {
            this.beatDelay -= BEAT_DELTA;
            this.beatTimer.setDelay(this.beatDelay);
        }
    }

    /**
     * Instantiates and starts a UFO timer set to go off in 5 seconds.
     */
    public void startUFOTimer ()
    {
        ufoTimer = new Timer(ALIEN_DELAY, this);
        ufoTimer.start();
    }

    /**
     * If the transition time has been reached, transition to a new state
     */
    private void performTransition ()
    {
        // Do something only if the time has been reached
        if (transitionTime <= System.currentTimeMillis())
        {
            // Clear the transition time
            transitionTime = Long.MAX_VALUE;

            // Game over transition
            if (lives == 0)
            {
                // Stop all audio clips
                this.sounds.terminateAllClips();
                
                // End timers
                this.beatTimer.stop();
                this.ufoTimer.stop();
                
                // Show "Game Over" screen
                finalScreen();
            }
            // Next level transition
            else if (lives > 0 && countAsteroids() == 0 && countUFOs() == 0)
            {
                // Stop all audio and advance to the next level
                this.sounds.terminateAllClips();
                this.level++;

                initialScreen();
            }
            // Player death transition
            else if (this.ship == null)
            {
                placeShip();
            }
        }
    }

    /**
     * Returns the number of asteroids that are active participants
     */
    private int countAsteroids ()
    {
        int count = 0;
        for (Participant p : this)
        {
            if (p instanceof Asteroid)
            {
                count++;
            }
        }
        return count;
    }

    /**
     * Returns the number of UFOs that are active participants
     */
    public int countUFOs ()
    {
        int count = 0;
        for (Participant p : this)
        {
            if (p instanceof UFO)
            {
                count++;
            }
        }
        return count;
    }

    /**
     * If a key of interest is pressed, record that it is down.
     */
    @Override
    public void keyPressed (KeyEvent e)
    {

        if (e.getKeyCode() == KeyEvent.VK_RIGHT && ship != null)
        {
            // Turn right
            ship.setThrusters(1, "right");
        }

        if (e.getKeyCode() == KeyEvent.VK_LEFT && ship != null)
        {
            // Turn left
            ship.setThrusters(1, "left");
        }

        if ((e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) && ship != null)
        {
            // Move forward
            ship.setThrusters(1, "forward");
        }

        if ((e.getKeyCode() == KeyEvent.VK_SPACE || e.getKeyCode() == KeyEvent.VK_DOWN
                || e.getKeyCode() == KeyEvent.VK_S) && ship != null)
        {
            // Fire the user ship's gun cannon
            ship.engageCannon("on");
        }
    }

    @Override
    public void keyTyped (KeyEvent e)
    {

    }

    @Override
    public void keyReleased (KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_RIGHT && ship != null)
        {
            ship.setThrusters(0, "right");
        }

        if (e.getKeyCode() == KeyEvent.VK_LEFT && ship != null)
        {
            ship.setThrusters(0, "left");
        }

        if ((e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) && ship != null)
        {
            ship.setThrusters(0, "forward");
        }

        if ((e.getKeyCode() == KeyEvent.VK_SPACE || e.getKeyCode() == KeyEvent.VK_DOWN
                || e.getKeyCode() == KeyEvent.VK_S) && ship != null)
        {
            ship.engageCannon("off");
        }
    }
}
