package asteroids.participants;

import static asteroids.game.Constants.BULLET_DURATION;
import static asteroids.game.Constants.BULLET_SPEED;
import java.awt.Shape;
import java.awt.geom.Path2D;
import asteroids.destroyers.AsteroidDestroyer;
import asteroids.destroyers.ShipDestroyer;
import asteroids.game.Constants;
import asteroids.game.Controller;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

public class Laser extends Participant implements AsteroidDestroyer, ShipDestroyer
{
    /** The outline of the bullet */
    private Shape outline;
    
    /** Game Controller */
    private Controller controller;
    
    /** Represents the outline shape of the bullet */
    private Path2D.Double poly = new Path2D.Double();
    
    /** Represents the specific UFO that is firing bullets, if one exists */
    private UFO ufo;
    
    /**
     * Constructs a laser object at the x and y coordinates of the given UFO.
     */
    public Laser(UFO ufo, Controller controller)
    {
        // Initialize the controller
        this.controller = controller;
        
        // Initialize this laser's UFO
        this.ufo = ufo;
        
        // Determine the laser's velocity
        if (this.ufo.getSize() == 1 && this.controller.getShip() != null)
        {
            // Randomly determine an error within [-5, 5] degrees inclusively
            double error = Math.toRadians(Constants.RANDOM.nextInt(11) - 5);
            
            // Direction of the ship is random at any moment, thus so is the laser
            this.setVelocity(BULLET_SPEED, this.controller.getShip().getDirection() + error); 
        }
        else if (this.controller.getShip() != null)
        {
            // Shoot in direction of the ship
            double x_diff = this.controller.getShip().getX() - this.ufo.getX();
            double y_diff = this.controller.getShip().getY() - this.ufo.getY();
            double theta = Math.atan2(y_diff, x_diff);
            this.setVelocity(BULLET_SPEED, theta);
        }
        
        // Now initialize the laser's shape outline
        poly.moveTo(ufo.getX() + 1, ufo.getY() + 1);
        poly.lineTo(ufo.getX() + 1, ufo.getY() - 1);
        poly.lineTo(ufo.getX() - 1, ufo.getY() - 1);
        poly.lineTo(ufo.getX() - 1, ufo.getY() + 1);
        poly.closePath();
        
        // Set the outline to this shape
        outline = poly;
        
        // Schedule laser expiration in 3 seconds
        new ParticipantCountdownTimer(this, "expire", BULLET_DURATION);   
    }
    
    /**
     * Returns the shape outline of this laser.
     */
    @Override
    protected Shape getOutline ()
    {
        // Return the shape outline
        return outline;
    }
    
    /**
     * This method is invoked when the laser collides with another participant.
     */
    @Override
    public void collidedWith (Participant p)
    {   
        // Expire the bullet
        Participant.expire(this);
    }
    
    /**
     * This method is invoked when this bullets ParticipantCountdownTimer completes
     */
    @Override
    public void countdownComplete (Object payload)
    {
        if (payload.equals("expire"))
        {
            // Expire this bullet
            Participant.expire(this);
        }
    }
}
