package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.destroyers.*;
import asteroids.game.Controller;
import asteroids.game.Participant;

/**
 * Represents ships
 */
public class Ship extends Participant implements AsteroidDestroyer, UFODestroyer
{
    /** Game controller */
    private Controller controller;

    /** Indicates whether the ship should be rotating rightward */
    private int right_thruster;

    /** Indicates whether the ship should be rotating leftward */
    private int left_thruster;

    /** Indicates whether the ship should be accelerating */
    private int forward_thruster;

    /** Indicates whether the ship is firing bullets */
    private int cannon;

    /** Represents the ship outline shape without a flame when acceleration mode is turned off */
    private Path2D.Double poly = new Path2D.Double();

    /** Represents the ship outline shape with a flame when acceleration mode is turned on */
    private Path2D.Double flame = new Path2D.Double();

    /** Represents the number of bullets currently active */
    private int bullet_num;

    /** Indicates if the ships flame is currently flickering */
    private boolean flickering;

    /**
     * Constructs a ship at the specified coordinates that is pointed in the given direction.
     */
    public Ship (int x, int y, double direction, Controller controller)
    {
        this.controller = controller;
        setPosition(x, y);
        setRotation(direction);

        // Initializing the regular ship shape outline
        poly.moveTo(21, 0);
        poly.lineTo(-21, 12);
        poly.lineTo(-14, 10);
        poly.lineTo(-14, -10);
        poly.lineTo(-21, -12);
        poly.closePath();

        // Initializing the ship shape outline when a flame is shown
        flame.moveTo(21, 0);
        flame.lineTo(-21, 12);
        flame.lineTo(-14, 10);
        flame.lineTo(-14, -10);
        flame.lineTo(-21, -12);
        flame.closePath();
        flame.moveTo(-20, 0);
        flame.lineTo(-14, 5);
        flame.lineTo(-14, -5);
        flame.closePath();

        // Setting the starting outline to the no flame shape
        flickering = true;

        // Set number of active bullets to 0
        bullet_num = 0;

        // Ship stars with cannon in off mode
        cannon = 0;
    }

    /**
     * Toggles the ship's cannon into on and off mode
     */
    public void engageCannon (String str)
    {
        if (str == "on" && hasBullet() == true)
        {
            this.cannon = 1;
        }

        if (str == "off")

        {
            this.cannon = 0;
        }
    }

    /**
     * Returns true the current value of bullet_num < 8.
     */
    private boolean hasBullet ()
    {
        /*
        // If less than 8 return true
        if (bullet_num < BULLET_LIMIT)
        {
            return true;
        }
        */

        return true;
    }

    /**
     * Expires one bullet
     */
    public void expireBullet ()
    {
        bullet_num--;
    }

    /**
     * Sets the right, left, and forward thrusters to on and off mode.
     * 
     * @param x must be 0 for 'off' or 1 for 'on'.
     * @param thruster must be either "right", "left", or "forward" to indicate which thruster to toggle on/off.
     */
    public void setThrusters (int x, String thruster)
    {
        if (thruster == "right")
        {
            this.right_thruster = x;
        }

        if (thruster == "left")
        {
            this.left_thruster = x;
        }

        if (thruster == "forward")
        {
            if (this.forward_thruster == 0 && x == 1)
            {
                // Play the ship thruster sound
                this.controller.getSounds().playClip("shipFlame", -1);
                this.forward_thruster = x;
            }
            else if (this.forward_thruster == 1 && x == 0)
            {
                this.controller.getSounds().terminateClip("shipFlame");
                this.forward_thruster = x;
            }
        }
    }

    /**
     * Returns the x-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getXNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getX();
    }

    /**
     * Returns the y-coordinate of the point on the screen where the ship's nose is located.
     */
    public double getYNose ()
    {
        Point2D.Double point = new Point2D.Double(20, 0);
        transformPoint(point);
        return point.getY();
    }

    @Override
    protected Shape getOutline ()
    {
        if (this.forward_thruster == 0)
        {
            return poly;
        }
        else
        {
            if (this.flickering)
            {
                this.flickering = false;
                return flame;
            }
            else
            {
                this.flickering = true;
                return poly;
            }
        }
    }

    /**
     * Customizes the base move method by imposing friction
     */
    @Override
    public void move ()
    {
        applyFriction(SHIP_FRICTION);
        super.move();

        if (this.left_thruster == 1)
        {
            turnLeft();
        }

        if (this.forward_thruster == 1)
        {
            accelerate();
        }

        if (this.right_thruster == 1)
        {
            turnRight();
        }

        if (this.cannon == 1)
        {
            if (this.hasBullet())
            {
                fireCannon();
                bullet_num++;
            }
        }
    }

    /**
     * Fires the ship's gun cannon
     */
    public void fireCannon ()
    {
        // Generate the ship cannon sound
        //this.controller.getSounds().playClip("shipBullet", 0);

        // First argument is the ship, second is the controller
        Bullet x = new Bullet(this, this.controller);

        // Adding the participant to the controller so objects interact correctly
        this.controller.addParticipant(x);
    }

    /**
     * Turns right by Pi/16 radians
     */
    public void turnRight ()
    {
        rotate(Math.PI / 16);
    }

    /**
     * Turns left by Pi/16 radians
     */
    public void turnLeft ()
    {
        rotate(-Math.PI / 16);
    }

    /**
     * Accelerates by SHIP_ACCELERATION
     */
    public void accelerate ()
    {

        accelerate(SHIP_ACCELERATION);
    }

    /**
     * This method is invoked when the Ship collides with another participant
     */
    @Override
    public void collidedWith (Participant p)
    {

        if (p instanceof ShipDestroyer)
        {
            // Turn off exhaust noise if it was on
            this.controller.getSounds().terminateClip("shipFlame");
            
            // Play ship destruction noise
            this.controller.getSounds().playClip("bangShip", 0);

            // Create ship debris
            controller.addParticipant(new Debris(24, this));
            controller.addParticipant(new Debris(24, this));
            controller.addParticipant(new Debris(20, this));
            controller.addParticipant(new Debris(2, this));
            controller.addParticipant(new Debris(2, this));

            // Expire the ship from the game
            Participant.expire(this);

            // Tell the controller the ship was destroyed
            controller.shipDestroyed();
        }
    }
}
