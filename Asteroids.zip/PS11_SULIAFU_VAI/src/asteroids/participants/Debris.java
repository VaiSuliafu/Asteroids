package asteroids.participants;

import static asteroids.game.Constants.*;
import asteroids.game.ParticipantCountdownTimer;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.game.Participant;

public class Debris extends Participant
{
    /** The outline of the ship debris */
    private Shape outline;

    /** Represents the specific ship generating this debris */
    private Ship ship;

    /** Represents the specific UFO generating this debris */
    private UFO ufo;

    /** Represents the first piece of the outline object */
    private Path2D.Double poly = new Path2D.Double();

    /**
     * Creates a debris of the specified length at the x and y coordinates of the specified ship.
     */
    public Debris (int length, Ship ship)
    {
        // Initialize the object
        this.ship = ship;

        // Set movement
        setVelocity(RANDOM.nextInt(3) + 1, RANDOM.nextDouble() * 2 * Math.PI);

        // Randomly generate int values with a fixed sum of 'length'
        int a = RANDOM.nextInt(length);
        int b = length - a;

        // Making a line randomly rotated line of length 'length'
        poly.moveTo(this.ship.getXNose(), this.ship.getYNose());
        poly.lineTo(this.ship.getXNose() + (a * randomOffset()), this.ship.getYNose() + (b * randomOffset()));

        // Set the outline to this shape
        outline = poly;

        // Schedule expiration in 2 seconds
        new ParticipantCountdownTimer(this, "expire", 2000);
    }

    /**
     * Creates a debris of the specified length at the x and y coordinates of the specified UFO.
     */
    public Debris (int length, UFO ufo)
    {
        // Initialize the object
        this.ufo = ufo;

        // Set movement
        setVelocity(RANDOM.nextInt(3) + 1, RANDOM.nextDouble() * 2 * Math.PI);

        // Randomly generate int values with a fixed sum of 'length'
        int a = RANDOM.nextInt(length);
        int b = length - a;

        // Making a line randomly rotated line of length 'length'
        poly.moveTo(this.ufo.getX(), this.ufo.getY());
        poly.lineTo(this.ufo.getX() + (a * randomOffset()), this.ufo.getY() + (b * randomOffset()));

        // Set the outline to this shape
        outline = poly;

        // Schedule expiration in 2 seconds
        new ParticipantCountdownTimer(this, "expire", 2000);
    }

    /**
     * Returns a random integer 'i' bound by the integer interval [-2, 2] (inclusive). The results are generated from a
     * uniform distribution.
     * 
     * @return
     */
    private int randomOffset ()
    {
        // 'a' will be the positive/negative off-setting
        // 'b' will be the magnitude of the offset
        int a = RANDOM.nextInt(2);

        if (a == 0)
        {
            a = -1;
        }

        return a;
    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    @Override
    public void collidedWith (Participant p)
    {
        // Nothing should happen when the debris is collided with
    }

    /**
     * This method is invoked when the debris ParticipantCountdownTimer completes
     */
    @Override
    public void countdownComplete (Object payload)
    {
        if (payload.equals("expire"))
        {
            // Expire this debris
            Participant.expire(this);
        }
    }

}
