package asteroids.participants;

import asteroids.destroyers.*;
import asteroids.game.Participant;
import asteroids.participants.Debris;
import asteroids.game.Controller;
import java.awt.Shape;
import java.awt.geom.Path2D;
import asteroids.game.Constants;
import asteroids.game.ParticipantCountdownTimer;

public class UFO extends Participant implements AsteroidDestroyer, ShipDestroyer
{
    /** Indicates the size of this UFO */
    private int size;

    /** The dynamic outline of the UFO */
    private Shape outline;

    /** Game controller */
    private Controller controller;

    /** Represents the 2D outline shape of the UFO */
    private Path2D.Double poly = new Path2D.Double();

    /** Represents the speed of a large UFO */
    private final static int LARGE_UFO_SPEED = 3;

    /** Indicates whether the UFO is moving in an increasing or decreasing direction */
    private int increasing;

    /** Indicates in which direction the UFO will move while zig-zagging */
    private double zigzag;

    /** Indicates the ships scaling factor */
    private double scale;

    /** Indicates whether the UFO is actively playing an audio clip */
    private boolean sound_on;

    /** Represents this UFO's audio clip type given this UFO's size */
    String sound_str;

    /**
     * Creates a UFO object of the specified size at the specified coordinates pointing in the specified direction.
     */
    public UFO (int size, int x, int y, double direction, Controller controller)
    {
        // Initialize beginning location & movement
        this.controller = controller;
        setPosition(x, y);
        setRotation(direction);
        this.size = size;

        // Set the ships scale
        scale = Constants.ALIENSHIP_SCALE[size];

        // Top square of UFO
        poly.moveTo(0 * scale, 12 * scale);
        poly.lineTo(0 * scale, 0 * scale);
        poly.lineTo(18 * scale, 0 * scale);
        poly.lineTo(18 * scale, 12 * scale);
        poly.closePath();

        // Top trapezoid of UFO
        poly.moveTo(-12 * scale, 21 * scale);
        poly.lineTo(-6 * scale, 12 * scale);
        poly.lineTo(24 * scale, 12 * scale);
        poly.lineTo(30 * scale, 21 * scale);
        poly.closePath();

        // Bottom trapezoid
        poly.moveTo(-6 * scale, 30 * scale);
        poly.lineTo(-12 * scale, 21 * scale);
        poly.lineTo(30 * scale, 21 * scale);
        poly.lineTo(24 * scale, 30 * scale);
        poly.closePath();

        // Assigning this shape to outline
        outline = poly;

        // Initialize the sound variables
        this.sound_on = false;

        if (this.size == 1)
        {
            this.sound_str = "ufoBig";
        }
        else if (this.size == 0)
        {
            this.sound_str = "ufoSmall";
        }

        // Randomizes the first movement refresh timer, which is bound by [1500ms, 25000ms]
        setMovementTimer();

        // Randomly determine the UFO's direction of movement
        int[] arr = { 1, 2 };
        this.increasing = arr[Constants.RANDOM.nextInt(2)];

        // Initialize the UFO as moving perfectly horizontal
        setVelocity((LARGE_UFO_SPEED / scale), zigzag);
    }

    /**
     * Returns this UFO's size
     */
    public int getSize ()
    {
        return this.size;
    }

    /**
     * Fires the UFO's laser cannon
     */
    public void fireLaser ()
    {
        // If a user ship exists, fire bullets
        if (this.controller.getShip() != null)
        {
            // First argument is the UFO, second is the controller
            Laser x = new Laser(this, this.controller);

            // Adding the participant to the controller so the objects interact correctly
            this.controller.addParticipant(x);
        }
    }

    /**
     * Randomly initializes this UFO's movement timer to a value between [1500ms, and 2500ms] inclusively.
     */
    private void setMovementTimer ()
    {
        new ParticipantCountdownTimer(this, "movementTimer", Constants.RANDOM.nextInt(1001) + 1500);
    }

    /**
     * Determines and assigns the value of zigzag based on the value of 'increasing'. Then, it sets the velocity and
     * direction to the specified arguments.
     * 
     * @param speed
     * @param direction
     */
    @Override
    public void setVelocity (double speed, double direction)
    {
        // Determine the value of zigzag
        if (this.increasing == 1)
        {
            double[] arr = { -1.0 + Math.PI, Math.PI, 1.0 + Math.PI };
            this.zigzag = arr[Constants.RANDOM.nextInt(3)];
        }
        else if (this.increasing == 2)
        {
            double[] arr = { -1.0, (Math.PI * 2), 1.0 };
            this.zigzag = arr[Constants.RANDOM.nextInt(3)];
        }

        // Invoke base class's setVelocity to actually alter the fields
        super.setVelocity(speed, direction);
    }

    /**
     * Returns the UFOs shape
     */
    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    /**
     * The method is invoked when a UFO collides with another participant
     */
    @Override
    public void collidedWith (Participant p)
    {
        if (p instanceof UFODestroyer)
        {
            // Play the UFO destruction audio clip
            this.controller.getSounds().playClip("bangUFO", 0);
            // Each element in this array roughly corresponds to the length
            // of one of the UFO's lines
            int[] debris_arr = { 12, 8, 8, 20, 20, 28, 28, 7, 7, 7, 7 };

            // Loop through array creating debris of these lengths
            for (int length : debris_arr)
            {
                // Calling Debris UFO constructor
                controller.addParticipant(new Debris(length, this));
            }
            
            // Terminate any sound that might have been applying
            this.controller.getSounds().terminateClip(this.sound_str);

            // Expire this UFO from the game
            Participant.expire(this);
            
            // Inform the controller
            this.controller.UFODestroyed();

            // Increment the score by the points for UFO destruction
            if (this.size == 1)
            {
                // A large/slow UFO is worth 200 points
                this.controller.setScore(200);
            }
            else if (this.size == 0)
            {
                // A small/fast UFO is worth 1000 points
                this.controller.setScore(1000);
            }

            // Tell the controller to restart the ufoTimer
            this.controller.startUFOTimer();
        }
    }

    /**
     * Implements the logic for the UFO's audio clip
     */
    private void controlSound ()
    {
        // If sound was off, play the clip continuously
        if (this.sound_on == false)
        {
            this.controller.getSounds().playClip(this.sound_str, -1);
            this.sound_on = true;
        }
        // If the clip is currently playing continuously, turn it off
        else if (this.sound_on == true)
        {
            this.controller.getSounds().terminateClip(this.sound_str);
            this.sound_on = false;
        }
    }

    /**
     * This method is invoked when a ParticipantCountdownTimer completes its count-down.
     */
    @Override
    public void countdownComplete (Object payload)
    {
        // If the movementTimer has gone off, change movement
        if (payload.equals("movementTimer") && this.isExpired() == false)
        {
            // Toggle the UFO sounds
            controlSound();

            // Fire a bullet
            fireLaser();

            // Change the velocity
            setVelocity((LARGE_UFO_SPEED / scale), zigzag);

            // Reset the timer
            setMovementTimer();
        }

    }
}
