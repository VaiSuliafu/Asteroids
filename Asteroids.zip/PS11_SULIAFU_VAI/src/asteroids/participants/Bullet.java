package asteroids.participants;

import java.awt.Shape;
import java.awt.geom.Path2D;
import asteroids.destroyers.AsteroidDestroyer;
import asteroids.destroyers.UFODestroyer;
import asteroids.game.Controller;
import static asteroids.game.Constants.*;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

public class Bullet extends Participant implements AsteroidDestroyer, UFODestroyer
{
    /** The outline of the bullet */
    private Shape outline;

    /** Represents the outline shape of the bullet */
    private Path2D.Double poly = new Path2D.Double();

    /** Represents the specific ship that is firing this bullet, if one exists */
    private Ship ship;

    /**
     * Constructs a Bullet object at the x and y coordinates of the given ships nose.
     * 
     * @param ship
     * @param controller
     */
    public Bullet (Ship ship, Controller controller)
    {
        // Initialize this bullet's ship
        this.ship = ship;

        // Setting the bullets velocity
        this.setVelocity(BULLET_SPEED, this.ship.getRotation());

        // Now initialize the bullets shape outline
        poly.moveTo(ship.getXNose() + 1, ship.getYNose() + 1);
        poly.lineTo(ship.getXNose() + 1, ship.getYNose() - 1);
        poly.lineTo(ship.getXNose() - 1, ship.getYNose() - 1);
        poly.lineTo(ship.getXNose() - 1, ship.getYNose() + 1);
        poly.closePath();

        // Set the outline to this shape
        outline = poly;

        // Schedule bullet expiration in 3 seconds
        new ParticipantCountdownTimer(this, "expire", BULLET_DURATION);
    }

    /**
     * Returns the shape outline of this bullet.
     */
    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    /**
     * This method is invoked when the bullet collides with another participant.
     */
    @Override
    public void collidedWith (Participant p)
    {
        // Expire the bullet
        Participant.expire(this);

        // Inform the ship that a bullet has expired
        this.ship.expireBullet();
    }

    /**
     * This method is invoked when this bullets ParticipantCountdownTimer completes
     */
    @Override
    public void countdownComplete (Object payload)
    {
        if (payload.equals("expire"))
        {
            // Expire this bullet
            Participant.expire(this);

            // Inform the ship the bullet expired
            this.ship.expireBullet();
        }
    }

}
