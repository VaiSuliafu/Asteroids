package asteroids.participants;

import static asteroids.game.Constants.*;
import java.awt.Shape;
import java.awt.geom.*;
import asteroids.game.Participant;
import asteroids.game.ParticipantCountdownTimer;

public class Dust extends Participant
{
    /** The outline of the space dust */
    private Shape outline;

    /** Represents the specific asteroid generating this dust */
    private Asteroid asteroid;

    /** Represents the Path2D.Double object that will serve as the outline */
    private Path2D.Double poly = new Path2D.Double();

    /**
     * Creates asteroid dust at the location of the specified asteroid.
     */
    public Dust (Asteroid asteroid)
    {
        // Initializing the object
        this.asteroid = asteroid;

        // Give the dust random velocity
        setVelocity(RANDOM.nextInt(4) + 1, this.asteroid.getRotation());

        // Randomly generate dust particles
        poly.moveTo(this.asteroid.getX() + randomOffset(), this.asteroid.getY() + randomOffset());
        poly.lineTo(this.asteroid.getX() + randomOffset(), this.asteroid.getY() + randomOffset());
        poly.closePath();

        // Set the outline to this shape
        outline = poly;

        // Schedule dust expiration in 2 seconds
        //new ParticipantCountdownTimer(this, "expire", 2000);
    }

    /**
     * Returns a random integer 'i' bound by the integer interval [-2, 2] (inclusive). The results are generated from a
     * uniform distribution.
     * 
     * @return
     */
    private int randomOffset ()
    {
        // 'a' will be the positive/negative off-setting
        // 'b' will be the magnitude of the offset
        int a = RANDOM.nextInt(2);
        int b = RANDOM.nextInt(3);

        if (a == 0)
        {
            a = -1;
        }

        return (a * b);
    }

    @Override
    protected Shape getOutline ()
    {
        return outline;
    }

    @Override
    public void collidedWith (Participant p)
    {
        // The ship dust shouldn't do anything when collided with.
    }

    /**
     * This method is invoked when the debris ParticipantCountdownTimer completes
     */
    @Override
    public void countdownComplete (Object payload)
    {
        if (payload.equals("expire"))
        {
            // Expire this debris
            Participant.expire(this);
        }
    }

}
