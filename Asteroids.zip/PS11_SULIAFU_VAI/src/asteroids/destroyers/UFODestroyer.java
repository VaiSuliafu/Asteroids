package asteroids.destroyers;

/**
 * Used to mark Participants that destroy UFOs.
 *
 */
public interface UFODestroyer
{

}
